@@ .. @@
 -- Remove all lead sequence progress except for the live test campaign
 DELETE FROM lead_sequence_progress 
-WHERE campaign_id != 'be239e0b-d75e-4ffc-ba0c-b693d157cb89';
+WHERE campaign_id != 'be239e0b-d75e-4ffc-ba0c-b693d157cb89';